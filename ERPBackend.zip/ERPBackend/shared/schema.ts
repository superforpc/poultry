import { sql } from "drizzle-orm";
import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table (existing)
export const users = sqliteTable("users", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Customers table - Updated to match requirements
export const customers = sqliteTable("customers", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  balance: real("balance").notNull().default(0),
  createdAt: text("created_at").notNull().default(sql`(datetime('now'))`),
});

// Vendors table - New as per requirements
export const vendors = sqliteTable("vendors", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  name: text("name").notNull(),
  balance: real("balance").notNull().default(0),
  createdAt: text("created_at").notNull().default(sql`(datetime('now'))`),
});

// Delivery Challans table - Updated to match requirements
export const deliveryChallans = sqliteTable("delivery_challans", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  dcNumber: text("dc_number").notNull().unique(),
  vendorId: text("vendor_id").notNull().references(() => vendors.id),
  date: text("date").notNull(), // ISO date string
  totalBirds: integer("total_birds").notNull().default(0),
  totalWeight: real("total_weight").notNull().default(0),
  purchaseRate: real("purchase_rate").notNull().default(0),
  cages: text("cages", { mode: "json" }).$type<Array<{
    cageNumber: string;
    birds: number;
    weight: number;
    rate: number;
    amount: number;
  }>>().notNull().default(sql`'[]'`),
  createdAt: text("created_at").notNull().default(sql`(datetime('now'))`),
});

// Invoices table - Updated to match requirements
export const invoices = sqliteTable("invoices", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  invoiceNumber: text("invoice_number").notNull().unique(),
  customerId: text("customer_id").notNull().references(() => customers.id),
  cages: text("cages", { mode: "json" }).$type<Array<{
    cageNumber: string;
    birds: number;
    weight: number;
    rate: number;
    amount: number;
  }>>().notNull().default(sql`'[]'`),
  subtotal: real("subtotal").notNull().default(0),
  tax: real("tax").notNull().default(0),
  total: real("total").notNull().default(0),
  paidAmount: real("paid_amount").notNull().default(0),
  dueAmount: real("due_amount").notNull().default(0),
  paymentMethod: text("payment_method"),
  status: text("status").notNull().default("draft"), // draft, paid, partial, overdue
  createdAt: text("created_at").notNull().default(sql`(datetime('now'))`),
});

// Ledger Entries table - Updated to match requirements
export const ledgerEntries = sqliteTable("ledger_entries", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(16))))`),
  relatedId: text("related_id"), // Reference to DC or Invoice ID
  type: text("type").notNull(), // purchase, invoice, payment
  customerOrVendorName: text("customer_or_vendor_name").notNull(),
  description: text("description").notNull(),
  amount: real("amount").notNull(),
  paid: real("paid").notNull().default(0),
  balance: real("balance").notNull().default(0),
  date: text("date").notNull(), // ISO date string
  createdAt: text("created_at").notNull().default(sql`(datetime('now'))`),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertCustomerSchema = createInsertSchema(customers).omit({ id: true, createdAt: true });
export const insertVendorSchema = createInsertSchema(vendors).omit({ id: true, createdAt: true });
export const insertDeliveryChallanSchema = createInsertSchema(deliveryChallans).omit({ id: true, createdAt: true });
export const insertInvoiceSchema = createInsertSchema(invoices).omit({ id: true, createdAt: true });
export const insertLedgerEntrySchema = createInsertSchema(ledgerEntries).omit({ id: true, createdAt: true });

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

export type InsertVendor = z.infer<typeof insertVendorSchema>;
export type Vendor = typeof vendors.$inferSelect;

export type InsertDeliveryChallan = z.infer<typeof insertDeliveryChallanSchema>;
export type DeliveryChallan = typeof deliveryChallans.$inferSelect;

export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoices.$inferSelect;

export type InsertLedgerEntry = z.infer<typeof insertLedgerEntrySchema>;
export type LedgerEntry = typeof ledgerEntries.$inferSelect;
