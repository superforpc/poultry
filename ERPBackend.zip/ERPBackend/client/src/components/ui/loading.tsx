import { Loader2 } from "lucide-react";

interface LoadingSpinnerProps {
  size?: "sm" | "md" | "lg";
  text?: string;
}

export function LoadingSpinner({ size = "md", text }: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: "h-4 w-4",
    md: "h-6 w-6", 
    lg: "h-8 w-8"
  };

  return (
    <div className="flex items-center justify-center space-x-2">
      <Loader2 className={`${sizeClasses[size]} animate-spin text-primary`} />
      {text && <span className="text-sm text-muted-foreground">{text}</span>}
    </div>
  );
}

export function LoadingCard({ className = "" }: { className?: string }) {
  return (
    <div className={`neuro-card p-6 ${className}`}>
      <div className="animate-pulse space-y-4">
        <div className="h-4 bg-muted rounded-lg w-3/4"></div>
        <div className="h-4 bg-muted rounded-lg w-1/2"></div>
        <div className="h-4 bg-muted rounded-lg w-2/3"></div>
      </div>
    </div>
  );
}

export function LoadingTable({ rows = 5 }: { rows?: number }) {
  return (
    <div className="neuro-card overflow-hidden">
      <div className="animate-pulse">
        {/* Header */}
        <div className="border-b border-border p-4">
          <div className="flex space-x-4">
            <div className="h-4 bg-muted rounded-lg flex-1"></div>
            <div className="h-4 bg-muted rounded-lg flex-1"></div>
            <div className="h-4 bg-muted rounded-lg flex-1"></div>
            <div className="h-4 bg-muted rounded-lg w-20"></div>
          </div>
        </div>
        
        {/* Rows */}
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="border-b border-border p-4 last:border-b-0">
            <div className="flex space-x-4">
              <div className="h-3 bg-muted rounded-lg flex-1"></div>
              <div className="h-3 bg-muted rounded-lg flex-1"></div>
              <div className="h-3 bg-muted rounded-lg flex-1"></div>
              <div className="h-3 bg-muted rounded-lg w-20"></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}