import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LoadingSpinner } from "@/components/ui/loading";
import { useCustomers } from "@/hooks/useApi";
import { Plus, Trash2 } from "lucide-react";
import type { Invoice, InvoiceFormData, CageData } from "@/types/api";

const cageSchema = z.object({
  cageNumber: z.string().min(1, "Cage number is required"),
  birds: z.number().min(1, "Birds count must be at least 1"),
  weight: z.number().min(0.1, "Weight must be greater than 0"),
  rate: z.number().min(0.01, "Rate must be greater than 0"),
  amount: z.number().min(0, "Amount cannot be negative")
});

const invoiceSchema = z.object({
  invoiceNumber: z.string().min(1, "Invoice number is required"),
  customerId: z.string().min(1, "Customer is required"),
  cages: z.array(cageSchema).min(1, "At least one cage is required"),
  subtotal: z.number().min(0, "Subtotal cannot be negative"),
  tax: z.number().min(0, "Tax cannot be negative"),
  total: z.number().min(0, "Total cannot be negative"),
  paidAmount: z.number().min(0, "Paid amount cannot be negative"),
  dueAmount: z.number().min(0, "Due amount cannot be negative"),
  paymentMethod: z.enum(["cash", "bank_transfer", "cheque", "online"]),
  status: z.enum(["pending", "partial", "paid", "overdue"])
});

interface InvoiceFormProps {
  invoice?: Invoice;
  onSubmit: (data: InvoiceFormData) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function InvoiceForm({ invoice, onSubmit, onCancel, isLoading }: InvoiceFormProps) {
  const { data: customersData } = useCustomers();
  const customers = customersData?.customers || [];

  const form = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceSchema),
    defaultValues: {
      invoiceNumber: invoice?.invoiceNumber || "",
      customerId: invoice?.customerId || "",
      cages: invoice?.cages || [{ cageNumber: "", birds: 0, weight: 0, rate: 0, amount: 0 }],
      subtotal: invoice?.subtotal || 0,
      tax: invoice?.tax || 0,
      total: invoice?.total || 0,
      paidAmount: invoice?.paidAmount || 0,
      dueAmount: invoice?.dueAmount || 0,
      paymentMethod: invoice?.paymentMethod || "cash",
      status: invoice?.status || "pending"
    }
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "cages"
  });

  const watchedCages = form.watch("cages");
  const watchedTotal = form.watch("total");
  const watchedPaid = form.watch("paidAmount");

  // Auto-calculate totals when cages change
  const calculateTotals = () => {
    const subtotal = watchedCages.reduce((sum, cage) => sum + (cage.amount || 0), 0);
    const tax = subtotal * 0.18; // 18% GST
    const total = subtotal + tax;
    const due = Math.max(0, total - watchedPaid);

    form.setValue("subtotal", subtotal);
    form.setValue("tax", tax);
    form.setValue("total", total);
    form.setValue("dueAmount", due);

    // Auto-update status based on payment
    if (watchedPaid >= total) {
      form.setValue("status", "paid");
    } else if (watchedPaid > 0) {
      form.setValue("status", "partial");
    } else {
      form.setValue("status", "pending");
    }
  };

  const addCage = () => {
    append({ cageNumber: "", birds: 0, weight: 0, rate: 0, amount: 0 });
  };

  const removeCage = (index: number) => {
    if (fields.length > 1) {
      remove(index);
    }
  };

  const handleCageChange = (index: number, field: keyof CageData, value: any) => {
    const updatedCages = [...watchedCages];
    updatedCages[index] = { ...updatedCages[index], [field]: value };
    
    // Auto-calculate amount if birds, weight, or rate changes
    if (field === "birds" || field === "weight" || field === "rate") {
      const cage = updatedCages[index];
      cage.amount = (cage.weight || 0) * (cage.rate || 0);
    }
    
    form.setValue("cages", updatedCages);
    setTimeout(calculateTotals, 0);
  };

  const handlePaidAmountChange = (value: number) => {
    form.setValue("paidAmount", value);
    const due = Math.max(0, watchedTotal - value);
    form.setValue("dueAmount", due);

    // Auto-update status
    if (value >= watchedTotal) {
      form.setValue("status", "paid");
    } else if (value > 0) {
      form.setValue("status", "partial");
    } else {
      form.setValue("status", "pending");
    }
  };

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="invoiceNumber">Invoice Number *</Label>
          <Input
            id="invoiceNumber"
            {...form.register("invoiceNumber")}
            className="neuro-input"
            placeholder="INV-2025-001"
          />
          {form.formState.errors.invoiceNumber && (
            <p className="text-sm text-destructive mt-1">
              {form.formState.errors.invoiceNumber.message}
            </p>
          )}
        </div>

        <div>
          <Label htmlFor="customerId">Customer *</Label>
          <Select
            value={form.watch("customerId")}
            onValueChange={(value) => form.setValue("customerId", value)}
          >
            <SelectTrigger className="neuro-input">
              <SelectValue placeholder="Select customer" />
            </SelectTrigger>
            <SelectContent>
              {customers.map((customer) => (
                <SelectItem key={customer.id} value={customer.id}>
                  {customer.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {form.formState.errors.customerId && (
            <p className="text-sm text-destructive mt-1">
              {form.formState.errors.customerId.message}
            </p>
          )}
        </div>
      </div>

      {/* Cages */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label>Items *</Label>
          <Button type="button" onClick={addCage} className="neuro-button">
            <Plus className="h-4 w-4 mr-2" />
            Add Item
          </Button>
        </div>

        {fields.map((field, index) => (
          <div key={field.id} className="neuro-inset p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Item {index + 1}</h4>
              {fields.length > 1 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removeCage(index)}
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div>
                <Label>Cage Number</Label>
                <Input
                  {...form.register(`cages.${index}.cageNumber`)}
                  className="neuro-input"
                  placeholder="CAGE-001"
                />
              </div>
              <div>
                <Label>Birds</Label>
                <Input
                  type="number"
                  min="0"
                  {...form.register(`cages.${index}.birds`, { valueAsNumber: true })}
                  onChange={(e) => handleCageChange(index, "birds", parseInt(e.target.value) || 0)}
                  className="neuro-input"
                />
              </div>
              <div>
                <Label>Weight (kg)</Label>
                <Input
                  type="number"
                  step="0.1"
                  min="0"
                  {...form.register(`cages.${index}.weight`, { valueAsNumber: true })}
                  onChange={(e) => handleCageChange(index, "weight", parseFloat(e.target.value) || 0)}
                  className="neuro-input"
                />
              </div>
              <div>
                <Label>Rate (₹/kg)</Label>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  {...form.register(`cages.${index}.rate`, { valueAsNumber: true })}
                  onChange={(e) => handleCageChange(index, "rate", parseFloat(e.target.value) || 0)}
                  className="neuro-input"
                />
              </div>
              <div>
                <Label>Amount (₹)</Label>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  {...form.register(`cages.${index}.amount`, { valueAsNumber: true })}
                  className="neuro-input"
                  readOnly
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Payment Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="font-medium">Payment Details</h3>
          
          <div>
            <Label htmlFor="paymentMethod">Payment Method</Label>
            <Select
              value={form.watch("paymentMethod")}
              onValueChange={(value: any) => form.setValue("paymentMethod", value)}
            >
              <SelectTrigger className="neuro-input">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cash">Cash</SelectItem>
                <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                <SelectItem value="cheque">Cheque</SelectItem>
                <SelectItem value="online">Online</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="paidAmount">Paid Amount (₹)</Label>
            <Input
              id="paidAmount"
              type="number"
              step="0.01"
              min="0"
              {...form.register("paidAmount", { valueAsNumber: true })}
              onChange={(e) => handlePaidAmountChange(parseFloat(e.target.value) || 0)}
              className="neuro-input"
            />
          </div>

          <div>
            <Label htmlFor="status">Status</Label>
            <Select
              value={form.watch("status")}
              onValueChange={(value: any) => form.setValue("status", value)}
            >
              <SelectTrigger className="neuro-input">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="partial">Partial</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Summary */}
        <div className="neuro-card p-4">
          <h3 className="font-medium mb-4">Invoice Summary</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <Label>Subtotal:</Label>
              <span className="font-mono">₹{form.watch("subtotal").toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <Label>Tax (18%):</Label>
              <span className="font-mono">₹{form.watch("tax").toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-lg font-semibold border-t pt-2">
              <Label>Total:</Label>
              <span className="font-mono">₹{form.watch("total").toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm text-muted-foreground">
              <Label>Paid:</Label>
              <span className="font-mono">₹{form.watch("paidAmount").toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm font-medium text-destructive">
              <Label>Due:</Label>   
              <span className="font-mono">₹{form.watch("dueAmount").toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex space-x-3 pt-4">
        <Button
          type="submit"
          disabled={isLoading}
          className="neuro-button flex-1"
        >
          {isLoading ? (
            <LoadingSpinner size="sm" />
          ) : (
            invoice ? "Update Invoice" : "Create Invoice"
          )}
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="neuro-button"
        >
          Cancel
        </Button>
      </div>
    </form>
  );
}