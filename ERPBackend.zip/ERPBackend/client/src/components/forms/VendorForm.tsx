import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LoadingSpinner } from "@/components/ui/loading";
import type { Vendor, VendorFormData } from "@/types/api";

const vendorSchema = z.object({
  name: z.string().min(1, "Name is required"),
  balance: z.number().min(0, "Balance cannot be negative")
});

interface VendorFormProps {
  vendor?: Vendor;
  onSubmit: (data: VendorFormData) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function VendorForm({ vendor, onSubmit, onCancel, isLoading }: VendorFormProps) {
  const form = useForm<VendorFormData>({
    resolver: zodResolver(vendorSchema),
    defaultValues: {
      name: vendor?.name || "",
      balance: vendor?.balance || 0
    }
  });

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Label htmlFor="name">Name *</Label>
        <Input
          id="name"
          {...form.register("name")}
          className="neuro-input"
          placeholder="Enter vendor name"
        />
        {form.formState.errors.name && (
          <p className="text-sm text-destructive mt-1">
            {form.formState.errors.name.message}
          </p>
        )}
      </div>

      <div>
        <Label htmlFor="balance">Balance (₹)</Label>
        <Input
          id="balance"
          type="number"
          step="0.01"
          min="0"
          {...form.register("balance", { valueAsNumber: true })}
          className="neuro-input"
          placeholder="Enter balance"
        />
        {form.formState.errors.balance && (
          <p className="text-sm text-destructive mt-1">
            {form.formState.errors.balance.message}
          </p>
        )}
      </div>

      <div className="flex space-x-3 pt-4">
        <Button
          type="submit"
          disabled={isLoading}
          className="neuro-button flex-1"
        >
          {isLoading ? (
            <LoadingSpinner size="sm" />
          ) : (
            vendor ? "Update Vendor" : "Create Vendor"
          )}
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="neuro-button"
        >
          Cancel
        </Button>
      </div>
    </form>
  );
}