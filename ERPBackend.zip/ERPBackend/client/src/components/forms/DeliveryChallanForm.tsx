import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LoadingSpinner } from "@/components/ui/loading";
import { useVendors } from "@/hooks/useApi";
import { Plus, Trash2 } from "lucide-react";
import type { DeliveryChallan, DeliveryChallanFormData, CageData } from "@/types/api";

const cageSchema = z.object({
  cageNumber: z.string().min(1, "Cage number is required"),
  birds: z.number().min(1, "Birds count must be at least 1"),
  weight: z.number().min(0.1, "Weight must be greater than 0"),
  rate: z.number().min(0.01, "Rate must be greater than 0"),
  amount: z.number().min(0, "Amount cannot be negative")
});

const deliveryChallanSchema = z.object({
  dcNumber: z.string().min(1, "DC number is required"),
  vendorName: z.string().optional(),
  vendorId: z.string().optional(),
  date: z.string().min(1, "Date is required"),
  totalBirds: z.number().min(1, "Total birds must be at least 1"),
  totalWeight: z.number().min(0.1, "Total weight must be greater than 0"),
  purchaseRate: z.number().min(0.01, "Purchase rate must be greater than 0"),
  cages: z.array(cageSchema).min(1, "At least one cage is required")
}).refine(data => data.vendorName || data.vendorId, {
  message: "Either vendor name or vendor selection is required"
});

interface DeliveryChallanFormProps {
  deliveryChallan?: DeliveryChallan;
  onSubmit: (data: DeliveryChallanFormData) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function DeliveryChallanForm({ deliveryChallan, onSubmit, onCancel, isLoading }: DeliveryChallanFormProps) {
  const { data: vendorsData } = useVendors();
  const vendors = vendorsData?.vendors || [];

  const form = useForm<DeliveryChallanFormData>({
    resolver: zodResolver(deliveryChallanSchema),
    defaultValues: {
      dcNumber: deliveryChallan?.dcNumber || "",
      vendorName: "",
      vendorId: deliveryChallan?.vendorId || "",
      date: deliveryChallan?.date ? new Date(deliveryChallan.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
      totalBirds: deliveryChallan?.totalBirds || 0,
      totalWeight: deliveryChallan?.totalWeight || 0,
      purchaseRate: deliveryChallan?.purchaseRate || 0,
      cages: deliveryChallan?.cages || [{ cageNumber: "", birds: 0, weight: 0, rate: 0, amount: 0 }]
    }
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "cages"
  });

  const watchedCages = form.watch("cages");

  // Auto-calculate totals when cages change
  const calculateTotals = () => {
    const totalBirds = watchedCages.reduce((sum, cage) => sum + (cage.birds || 0), 0);
    const totalWeight = watchedCages.reduce((sum, cage) => sum + (cage.weight || 0), 0);
    const totalAmount = watchedCages.reduce((sum, cage) => sum + (cage.amount || 0), 0);
    const avgRate = totalWeight > 0 ? totalAmount / totalWeight : 0;

    form.setValue("totalBirds", totalBirds);
    form.setValue("totalWeight", totalWeight);
    form.setValue("purchaseRate", avgRate);
  };

  const addCage = () => {
    append({ cageNumber: "", birds: 0, weight: 0, rate: 0, amount: 0 });
  };

  const removeCage = (index: number) => {
    if (fields.length > 1) {
      remove(index);
    }
  };

  const handleCageChange = (index: number, field: keyof CageData, value: any) => {
    const updatedCages = [...watchedCages];
    updatedCages[index] = { ...updatedCages[index], [field]: value };
    
    // Auto-calculate amount if birds, weight, or rate changes
    if (field === "birds" || field === "weight" || field === "rate") {
      const cage = updatedCages[index];
      cage.amount = (cage.weight || 0) * (cage.rate || 0);
    }
    
    form.setValue("cages", updatedCages);
    setTimeout(calculateTotals, 0);
  };

  const handleSubmit = (data: DeliveryChallanFormData) => {
    const submitData = {
      ...data,
      date: new Date(data.date).toISOString(),
      vendorName: data.vendorName || undefined,
      vendorId: data.vendorId || undefined
    };
    onSubmit(submitData);
  };

  return (
    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="dcNumber">DC Number *</Label>
          <Input
            id="dcNumber"
            {...form.register("dcNumber")}
            className="neuro-input"
            placeholder="Enter DC number"
          />
          {form.formState.errors.dcNumber && (
            <p className="text-sm text-destructive mt-1">
              {form.formState.errors.dcNumber.message}
            </p>
          )}
        </div>

        <div>
          <Label htmlFor="date">Date *</Label>
          <Input
            id="date"
            type="date"
            {...form.register("date")}
            className="neuro-input"
          />
          {form.formState.errors.date && (
            <p className="text-sm text-destructive mt-1">
              {form.formState.errors.date.message}
            </p>
          )}
        </div>
      </div>

      {/* Vendor Selection */}
      <div className="space-y-4">
        <div>
          <Label>Vendor *</Label>
          <div className="space-y-2">
            <Select
              value={form.watch("vendorId")}
              onValueChange={(value) => {
                if (value) {
                  form.setValue("vendorId", value);
                  form.setValue("vendorName", "");
                }
              }}
            >
              <SelectTrigger className="neuro-input">
                <SelectValue placeholder="Select existing vendor" />
              </SelectTrigger>
              <SelectContent>
                {vendors.map((vendor) => (
                  <SelectItem key={vendor.id} value={vendor.id}>
                    {vendor.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <div className="text-center text-sm text-muted-foreground">OR</div>
            
            <Input
              placeholder="Enter new vendor name"
              {...form.register("vendorName")}
              className="neuro-input"
              onChange={(e) => {
                form.setValue("vendorName", e.target.value);
                if (e.target.value) {
                  form.setValue("vendorId", "");
                }
              }}
            />
          </div>
          {form.formState.errors.vendorName && (
            <p className="text-sm text-destructive mt-1">
              {form.formState.errors.vendorName.message}
            </p>
          )}
        </div>
      </div>

      {/* Cages */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label>Cages *</Label>
          <Button type="button" onClick={addCage} className="neuro-button">
            <Plus className="h-4 w-4 mr-2" />
            Add Cage
          </Button>
        </div>

        {fields.map((field, index) => (
          <div key={field.id} className="neuro-inset p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Cage {index + 1}</h4>
              {fields.length > 1 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removeCage(index)}
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div>
                <Label>Cage Number</Label>
                <Input
                  {...form.register(`cages.${index}.cageNumber`)}
                  className="neuro-input"
                  placeholder="CAGE-001"
                />
              </div>
              <div>
                <Label>Birds</Label>
                <Input
                  type="number"
                  min="0"
                  {...form.register(`cages.${index}.birds`, { valueAsNumber: true })}
                  onChange={(e) => handleCageChange(index, "birds", parseInt(e.target.value) || 0)}
                  className="neuro-input"
                />
              </div>
              <div>
                <Label>Weight (kg)</Label>
                <Input
                  type="number"
                  step="0.1"
                  min="0"
                  {...form.register(`cages.${index}.weight`, { valueAsNumber: true })}
                  onChange={(e) => handleCageChange(index, "weight", parseFloat(e.target.value) || 0)}
                  className="neuro-input"
                />
              </div>
              <div>
                <Label>Rate (₹/kg)</Label>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  {...form.register(`cages.${index}.rate`, { valueAsNumber: true })}
                  onChange={(e) => handleCageChange(index, "rate", parseFloat(e.target.value) || 0)}
                  className="neuro-input"
                />
              </div>
              <div>
                <Label>Amount (₹)</Label>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  {...form.register(`cages.${index}.amount`, { valueAsNumber: true })}
                  className="neuro-input"
                  readOnly
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="neuro-card p-4">
        <h3 className="font-medium mb-4">Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label>Total Birds</Label>
            <Input
              {...form.register("totalBirds", { valueAsNumber: true })}
              className="neuro-input"
              readOnly
            />
          </div>
          <div>
            <Label>Total Weight (kg)</Label>
            <Input
              {...form.register("totalWeight", { valueAsNumber: true })}
              className="neuro-input"
              readOnly
            />
          </div>
          <div>
            <Label>Average Rate (₹/kg)</Label>
            <Input
              {...form.register("purchaseRate", { valueAsNumber: true })}
              className="neuro-input"
              readOnly
            />
          </div>
        </div>
      </div>

      <div className="flex space-x-3 pt-4">
        <Button
          type="submit"
          disabled={isLoading}
          className="neuro-button flex-1"
        >
          {isLoading ? (
            <LoadingSpinner size="sm" />
          ) : (
            deliveryChallan ? "Update Delivery Challan" : "Create Delivery Challan"
          )}
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="neuro-button"
        >
          Cancel
        </Button>
      </div>
    </form>
  );
}