import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LoadingSpinner } from "@/components/ui/loading";
import type { Customer, CustomerFormData } from "@/types/api";

const customerSchema = z.object({
  name: z.string().min(1, "Name is required"),
  phone: z.string().optional(),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  balance: z.number().min(0, "Balance cannot be negative")
});

interface CustomerFormProps {
  customer?: Customer;
  onSubmit: (data: CustomerFormData) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function CustomerForm({ customer, onSubmit, onCancel, isLoading }: CustomerFormProps) {
  const form = useForm<CustomerFormData>({
    resolver: zodResolver(customerSchema),
    defaultValues: {
      name: customer?.name || "",
      phone: customer?.phone || "",
      email: customer?.email || "",
      balance: customer?.balance || 0
    }
  });

  const handleSubmit = (data: CustomerFormData) => {
    // Convert empty strings to undefined for optional fields
    const cleanData = {
      ...data,
      phone: data.phone || undefined,
      email: data.email || undefined
    };
    onSubmit(cleanData);
  };

  return (
    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
      <div>
        <Label htmlFor="name">Name *</Label>
        <Input
          id="name"
          {...form.register("name")}
          className="neuro-input"
          placeholder="Enter customer name"
        />
        {form.formState.errors.name && (
          <p className="text-sm text-destructive mt-1">
            {form.formState.errors.name.message}
          </p>
        )}
      </div>

      <div>
        <Label htmlFor="phone">Phone</Label>
        <Input
          id="phone"
          {...form.register("phone")}
          className="neuro-input"
          placeholder="Enter phone number"
        />
        {form.formState.errors.phone && (
          <p className="text-sm text-destructive mt-1">
            {form.formState.errors.phone.message}
          </p>
        )}
      </div>

      <div>
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          {...form.register("email")}
          className="neuro-input"
          placeholder="Enter email address"
        />
        {form.formState.errors.email && (
          <p className="text-sm text-destructive mt-1">
            {form.formState.errors.email.message}
          </p>
        )}
      </div>

      <div>
        <Label htmlFor="balance">Balance (₹)</Label>
        <Input
          id="balance"
          type="number"
          step="0.01"
          min="0"
          {...form.register("balance", { valueAsNumber: true })}
          className="neuro-input"
          placeholder="Enter balance"
        />
        {form.formState.errors.balance && (
          <p className="text-sm text-destructive mt-1">
            {form.formState.errors.balance.message}
          </p>
        )}
      </div>

      <div className="flex space-x-3 pt-4">
        <Button
          type="submit"
          disabled={isLoading}
          className="neuro-button flex-1"
        >
          {isLoading ? (
            <LoadingSpinner size="sm" />
          ) : (
            customer ? "Update Customer" : "Create Customer"
          )}
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="neuro-button"
        >
          Cancel
        </Button>
      </div>
    </form>
  );
}