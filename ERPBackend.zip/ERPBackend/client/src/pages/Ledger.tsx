import { useState } from "react";
import { useLedger, useCustomers, useVendors } from "@/hooks/useApi";
import { LoadingTable } from "@/components/ui/loading";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, BookOpen, TrendingUp, TrendingDown, Minus } from "lucide-react";
import type { LedgerEntry } from "@/types/api";

const typeColors = {
  purchase: "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300",
  invoice: "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300",
  payment: "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
};

export default function Ledger() {
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [customerFilter, setCustomerFilter] = useState("");
  const [vendorFilter, setVendorFilter] = useState("");

  const { data, isLoading } = useLedger();
  const { data: customersData } = useCustomers();
  const { data: vendorsData } = useVendors();

  const ledgerEntries = data?.ledgerEntries || [];
  const customers = customersData?.customers || [];
  const vendors = vendorsData?.vendors || [];

  // Filter ledger entries
  const filteredEntries = ledgerEntries.filter(entry => {
    const matchesSearch = entry.customerOrVendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = !typeFilter || typeFilter === "all" || entry.type === typeFilter;
    
    // For customer/vendor filter, we need to match the name since ledger doesn't have direct IDs
    const matchesCustomer = !customerFilter || customerFilter === "all" || 
      customers.find(c => c.id === customerFilter)?.name === entry.customerOrVendorName;
    const matchesVendor = !vendorFilter || vendorFilter === "all" || 
      vendors.find(v => v.id === vendorFilter)?.name === entry.customerOrVendorName;

    return matchesSearch && matchesType && (!customerFilter || matchesCustomer) && (!vendorFilter || matchesVendor);
  });

  // Calculate summary stats
  const totalPurchases = ledgerEntries
    .filter(entry => entry.type === 'purchase')
    .reduce((sum, entry) => sum + entry.amount, 0);

  const totalInvoices = ledgerEntries
    .filter(entry => entry.type === 'invoice')
    .reduce((sum, entry) => sum + entry.amount, 0);

  const totalOutstanding = ledgerEntries
    .filter(entry => entry.balance > 0)
    .reduce((sum, entry) => sum + entry.balance, 0);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'purchase':
        return <TrendingDown className="h-4 w-4" />;
      case 'invoice':
        return <TrendingUp className="h-4 w-4" />;
      case 'payment':
        return <Minus className="h-4 w-4" />;
      default:
        return <BookOpen className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center">
            <BookOpen className="h-8 w-8 mr-3 text-primary" />
            Ledger
          </h1>
          <p className="text-muted-foreground mt-1">
            Track all financial transactions and balances
          </p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="neuro-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Purchases</p>
                <p className="text-2xl font-bold text-red-600">₹{totalPurchases.toLocaleString()}</p>
              </div>
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-900/20">
                <TrendingDown className="h-6 w-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="neuro-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Sales</p>
                <p className="text-2xl font-bold text-green-600">₹{totalInvoices.toLocaleString()}</p>
              </div>
              <div className="p-3 rounded-xl bg-green-50 dark:bg-green-900/20">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="neuro-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Outstanding</p>
                <p className="text-2xl font-bold text-orange-600">₹{totalOutstanding.toLocaleString()}</p>
              </div>
              <div className="p-3 rounded-xl bg-orange-50 dark:bg-orange-900/20">
                <BookOpen className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="neuro-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Net Position</p>
                <p className={`text-2xl font-bold ${totalInvoices >= totalPurchases ? 'text-green-600' : 'text-red-600'}`}>
                  ₹{Math.abs(totalInvoices - totalPurchases).toLocaleString()}
                </p>
              </div>
              <div className={`p-3 rounded-xl ${totalInvoices >= totalPurchases ? 'bg-green-50 dark:bg-green-900/20' : 'bg-red-50 dark:bg-red-900/20'}`}>
                {totalInvoices >= totalPurchases ? (
                  <TrendingUp className="h-6 w-6 text-green-600" />
                ) : (
                  <TrendingDown className="h-6 w-6 text-red-600" />
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        <div className="lg:col-span-2">
          <Card className="neuro-card">
            <CardContent className="p-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or description..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="neuro-input pl-10"
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="neuro-card">
          <CardContent className="p-4">
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="neuro-input">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="purchase">Purchase</SelectItem>
                <SelectItem value="invoice">Invoice</SelectItem>
                <SelectItem value="payment">Payment</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <Card className="neuro-card">
          <CardContent className="p-4">
            <Select value={customerFilter} onValueChange={setCustomerFilter}>
              <SelectTrigger className="neuro-input">
                <SelectValue placeholder="Filter by customer" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Customers</SelectItem>
                {customers.map((customer) => (
                  <SelectItem key={customer.id} value={customer.id}>
                    {customer.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <Card className="neuro-card">
          <CardContent className="p-4">
            <Select value={vendorFilter} onValueChange={setVendorFilter}>
              <SelectTrigger className="neuro-input">
                <SelectValue placeholder="Filter by vendor" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Vendors</SelectItem>
                {vendors.map((vendor) => (
                  <SelectItem key={vendor.id} value={vendor.id}>
                    {vendor.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
      </div>

      {/* Ledger Table */}
      <Card className="neuro-card">
        <CardHeader>
          <CardTitle>All Transactions</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <LoadingTable rows={8} />
          ) : filteredEntries.length === 0 ? (
            <div className="text-center py-12">
              <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-lg font-medium text-foreground mb-2">
                {searchTerm || typeFilter || customerFilter || vendorFilter ? "No transactions found" : "No transactions yet"}
              </p>
              <p className="text-muted-foreground">
                {searchTerm || typeFilter || customerFilter || vendorFilter
                  ? "Try adjusting your search or filters"
                  : "Transactions will appear here when you create delivery challans or invoices"
                }
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left p-4 font-medium text-muted-foreground">Date</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Type</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Party</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Description</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Amount</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Paid</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Balance</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEntries
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .map((entry) => (
                    <tr key={entry.id} className="border-b border-border last:border-b-0 hover:bg-muted/50">
                      <td className="p-4">
                        <p className="text-sm text-muted-foreground">
                          {new Date(entry.date).toLocaleDateString()}
                        </p>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center space-x-2">
                          {getTypeIcon(entry.type)}
                          <Badge className={`${typeColors[entry.type]} border-0`}>
                            {entry.type.charAt(0).toUpperCase() + entry.type.slice(1)}
                          </Badge>
                        </div>
                      </td>
                      <td className="p-4">
                        <p className="font-medium text-foreground">{entry.customerOrVendorName}</p>
                      </td>
                      <td className="p-4">
                        <p className="text-sm text-foreground">{entry.description}</p>
                      </td>
                      <td className="p-4">
                        <p className="font-mono font-medium">₹{entry.amount.toLocaleString()}</p>
                      </td>
                      <td className="p-4">
                        <p className="font-mono text-green-600">₹{entry.paid.toLocaleString()}</p>
                      </td>
                      <td className="p-4">
                        <p className={`font-mono font-medium ${entry.balance > 0 ? 'text-red-600' : 'text-muted-foreground'}`}>
                          ₹{entry.balance.toLocaleString()}
                        </p>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}