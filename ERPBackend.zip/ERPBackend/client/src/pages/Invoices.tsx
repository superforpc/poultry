import { useState } from "react";
import { useInvoices, useCreateInvoice, useCustomers } from "@/hooks/useApi";
import { LoadingTable } from "@/components/ui/loading";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InvoiceForm } from "@/components/forms/InvoiceForm";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Receipt, Eye } from "lucide-react";
import type { Invoice, InvoiceFormData } from "@/types/api";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300",
  partial: "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300",
  paid: "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300",
  overdue: "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
};

export default function Invoices() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [customerFilter, setCustomerFilter] = useState("");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [viewingInvoice, setViewingInvoice] = useState<Invoice | null>(null);

  const { data, isLoading } = useInvoices();
  const { data: customersData } = useCustomers();
  const createInvoice = useCreateInvoice();

  const invoices = data?.invoices || [];
  const customers = customersData?.customers || [];

  // Create customer lookup map
  const customerMap = customers.reduce((acc, customer) => {
    acc[customer.id] = customer.name;
    return acc;
  }, {} as Record<string, string>);

  // Filter invoices
  const filteredInvoices = invoices.filter(invoice => {
    const customerName = customerMap[invoice.customerId] || "Unknown";
    const matchesSearch = invoice.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         customerName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = !statusFilter || statusFilter === "all" || invoice.status === statusFilter;
    const matchesCustomer = !customerFilter || customerFilter === "all" || invoice.customerId === customerFilter;
    return matchesSearch && matchesStatus && matchesCustomer;
  });

  const handleCreateInvoice = async (data: InvoiceFormData) => {
    await createInvoice.mutateAsync(data);
    setIsFormOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center">
            <Receipt className="h-8 w-8 mr-3 text-primary" />
            Invoices
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage customer invoices and billing
          </p>
        </div>
        <Button
          onClick={() => setIsFormOpen(true)}
          className="neuro-button"
        >
          <Plus className="h-4 w-4 mr-2" />
          Create Invoice
        </Button>
      </div>

      {/* Search and Filters */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        <div className="lg:col-span-2">
          <Card className="neuro-card">
            <CardContent className="p-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by invoice number or customer..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="neuro-input pl-10"
                />
              </div>
            </CardContent>
          </Card>
        </div>
        <Card className="neuro-card">
          <CardContent className="p-4">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="neuro-input">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="partial">Partial</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
        <Card className="neuro-card">
          <CardContent className="p-4">
            <Select value={customerFilter} onValueChange={setCustomerFilter}>
              <SelectTrigger className="neuro-input">
                <SelectValue placeholder="Filter by customer" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Customers</SelectItem>
                {customers.map((customer) => (
                  <SelectItem key={customer.id} value={customer.id}>
                    {customer.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
        <Card className="neuro-card">
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-primary">{invoices.length}</p>
              <p className="text-sm text-muted-foreground">Total Invoices</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Invoices Table */}
      <Card className="neuro-card">
        <CardHeader>
          <CardTitle>All Invoices</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <LoadingTable rows={5} />
          ) : filteredInvoices.length === 0 ? (
            <div className="text-center py-12">
              <Receipt className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-lg font-medium text-foreground mb-2">
                {searchTerm || statusFilter || customerFilter ? "No invoices found" : "No invoices yet"}
              </p>
              <p className="text-muted-foreground mb-4">
                {searchTerm || statusFilter || customerFilter
                  ? "Try adjusting your search or filters" 
                  : "Get started by creating your first invoice"
                }
              </p>
              {!searchTerm && !statusFilter && !customerFilter && (
                <Button
                  onClick={() => setIsFormOpen(true)}
                  className="neuro-button"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create Invoice
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left p-4 font-medium text-muted-foreground">Invoice #</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Customer</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Amount</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Status</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Due</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Date</th>
                    <th className="text-right p-4 font-medium text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredInvoices.map((invoice) => (
                    <tr key={invoice.id} className="border-b border-border last:border-b-0 hover:bg-muted/50">
                      <td className="p-4">
                        <p className="font-medium text-foreground">{invoice.invoiceNumber}</p>
                      </td>
                      <td className="p-4">
                        <p className="text-foreground">{customerMap[invoice.customerId] || "Unknown"}</p>
                      </td>
                      <td className="p-4">
                        <p className="font-mono font-medium">₹{invoice.total.toLocaleString()}</p>
                      </td>
                      <td className="p-4">
                        <Badge 
                          className={`${statusColors[invoice.status]} border-0`}
                        >
                          {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <p className="font-mono text-sm">
                          {invoice.dueAmount > 0 ? (
                            <span className="text-destructive">₹{invoice.dueAmount.toLocaleString()}</span>
                          ) : (
                            <span className="text-muted-foreground">₹0</span>
                          )}
                        </p>
                      </td>
                      <td className="p-4">
                        <p className="text-sm text-muted-foreground">
                          {new Date(invoice.createdAt).toLocaleDateString()}
                        </p>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-end space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setViewingInvoice(invoice)}
                            className="neuro-button"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Invoice Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="neuro-card border-0 max-w-4xl" aria-describedby="invoice-dialog-description">
          <DialogHeader>
            <DialogTitle>Create New Invoice</DialogTitle>
          </DialogHeader>
          <div id="invoice-dialog-description" className="sr-only">
            Create a new invoice for billing customers
          </div>
          <InvoiceForm
            onSubmit={handleCreateInvoice}
            onCancel={() => setIsFormOpen(false)}
            isLoading={createInvoice.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* View Invoice Dialog */}
      <Dialog open={!!viewingInvoice} onOpenChange={() => setViewingInvoice(null)}>
        <DialogContent className="neuro-card border-0 max-w-4xl" aria-describedby="invoice-view-description">
          <DialogHeader>
            <DialogTitle>Invoice Details</DialogTitle>
          </DialogHeader>
          <div id="invoice-view-description" className="sr-only">
            View detailed information about the selected invoice
          </div>
          {viewingInvoice && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Invoice Number</Label>
                  <p className="text-lg font-semibold">{viewingInvoice.invoiceNumber}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Customer</Label>
                  <p className="text-lg">{customerMap[viewingInvoice.customerId] || "Unknown"}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Payment Method</Label>
                  <p className="text-lg capitalize">{viewingInvoice.paymentMethod.replace('_', ' ')}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Status</Label>
                  <Badge className={`${statusColors[viewingInvoice.status]} border-0`}>
                    {viewingInvoice.status.charAt(0).toUpperCase() + viewingInvoice.status.slice(1)}
                  </Badge>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">Items</h3>
                <div className="space-y-3">
                  {viewingInvoice.cages.map((cage, index) => (
                    <div key={index} className="neuro-inset p-4">
                      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">Cage</Label>
                          <p className="font-medium">{cage.cageNumber}</p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">Birds</Label>
                          <p>{cage.birds}</p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">Weight</Label>
                          <p>{cage.weight} kg</p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">Rate</Label>
                          <p>₹{cage.rate.toFixed(2)}/kg</p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">Amount</Label>
                          <p className="font-semibold">₹{cage.amount.toFixed(2)}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="neuro-card p-4">
                <h4 className="font-semibold mb-4">Payment Summary</h4>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <Label>Subtotal:</Label>
                    <span className="font-mono">₹{viewingInvoice.subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <Label>Tax:</Label>
                    <span className="font-mono">₹{viewingInvoice.tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-lg font-semibold border-t pt-2">
                    <Label>Total:</Label>
                    <span className="font-mono">₹{viewingInvoice.total.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-green-600">
                    <Label>Paid:</Label>
                    <span className="font-mono">₹{viewingInvoice.paidAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-red-600 font-semibold">
                    <Label>Due:</Label>
                    <span className="font-mono">₹{viewingInvoice.dueAmount.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}