import { useState } from "react";
import { useVendors, useCreateVendor, useUpdateVendor, useDeleteVendor } from "@/hooks/useApi";
import { LoadingTable } from "@/components/ui/loading";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { VendorForm } from "@/components/forms/VendorForm";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Edit, Trash2, Truck } from "lucide-react";
import type { Vendor, VendorFormData } from "@/types/api";

export default function Vendors() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingVendor, setEditingVendor] = useState<Vendor | null>(null);
  const [deleteVendor, setDeleteVendor] = useState<Vendor | null>(null);

  const { data, isLoading } = useVendors();
  const createVendor = useCreateVendor();
  const updateVendor = useUpdateVendor();
  const deleteVendorMutation = useDeleteVendor();

  const vendors = data?.vendors || [];

  const filteredVendors = vendors.filter(vendor =>
    vendor.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCreateVendor = async (data: VendorFormData) => {
    await createVendor.mutateAsync(data);
    setIsFormOpen(false);
  };

  const handleUpdateVendor = async (data: VendorFormData) => {
    if (editingVendor) {
      await updateVendor.mutateAsync({ id: editingVendor.id, data });
      setEditingVendor(null);
    }
  };

  const handleDeleteVendor = async () => {
    if (deleteVendor) {
      await deleteVendorMutation.mutateAsync(deleteVendor.id);
      setDeleteVendor(null);
    }
  };

  const openEditForm = (vendor: Vendor) => {
    setEditingVendor(vendor);
  };

  const closeForm = () => {
    setIsFormOpen(false);
    setEditingVendor(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center">
            <Truck className="h-8 w-8 mr-3 text-primary" />
            Vendors
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage your vendor database
          </p>
        </div>
        <Button
          onClick={() => setIsFormOpen(true)}
          className="neuro-button"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Vendor
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3">
          <Card className="neuro-card">
            <CardContent className="p-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search vendors by name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="neuro-input pl-10"
                />
              </div>
            </CardContent>
          </Card>
        </div>
        <Card className="neuro-card">
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-primary">{vendors.length}</p>
              <p className="text-sm text-muted-foreground">Total Vendors</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="neuro-card">
        <CardHeader>
          <CardTitle>All Vendors</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <LoadingTable rows={5} />
          ) : filteredVendors.length === 0 ? (
            <div className="text-center py-12">
              <Truck className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-lg font-medium text-foreground mb-2">
                {searchTerm ? "No vendors found" : "No vendors yet"}
              </p>
              <p className="text-muted-foreground mb-4">
                {searchTerm 
                  ? "Try adjusting your search terms" 
                  : "Get started by adding your first vendor"
                }
              </p>
              {!searchTerm && (
                <Button
                  onClick={() => setIsFormOpen(true)}
                  className="neuro-button"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Vendor
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left p-4 font-medium text-muted-foreground">Name</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Balance</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Created</th>
                    <th className="text-right p-4 font-medium text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredVendors.map((vendor) => (
                    <tr key={vendor.id} className="border-b border-border last:border-b-0 hover:bg-muted/50">
                      <td className="p-4">
                        <p className="font-medium text-foreground">{vendor.name}</p>
                      </td>
                      <td className="p-4">
                        <Badge 
                          variant={vendor.balance >= 0 ? "default" : "destructive"}
                          className="font-mono"
                        >
                          ₹{vendor.balance.toLocaleString()}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <p className="text-sm text-muted-foreground">
                          {new Date(vendor.createdAt).toLocaleDateString()}
                        </p>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-end space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditForm(vendor)}
                            className="neuro-button"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setDeleteVendor(vendor)}
                            className="neuro-button text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isFormOpen || !!editingVendor} onOpenChange={closeForm}>
        <DialogContent className="neuro-card border-0" aria-describedby="vendor-dialog-description">
          <DialogHeader>
            <DialogTitle>
              {editingVendor ? "Edit Vendor" : "Add New Vendor"}
            </DialogTitle>
          </DialogHeader>
          <div id="vendor-dialog-description" className="sr-only">
            {editingVendor ? "Edit vendor information" : "Add a new vendor to your database"}
          </div>
          <VendorForm
            vendor={editingVendor || undefined}
            onSubmit={editingVendor ? handleUpdateVendor : handleCreateVendor}
            onCancel={closeForm}
            isLoading={createVendor.isPending || updateVendor.isPending}
          />
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteVendor} onOpenChange={() => setDeleteVendor(null)}>
        <AlertDialogContent className="neuro-card border-0">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Vendor</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deleteVendor?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="neuro-button">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteVendor}
              disabled={deleteVendorMutation.isPending}
              className="neuro-button bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}