import { useState } from "react";
import { useDeliveryChallans, useCreateDeliveryChallan, useVendors } from "@/hooks/useApi";
import { LoadingTable } from "@/components/ui/loading";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DeliveryChallanForm } from "@/components/forms/DeliveryChallanForm";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, FileText, Eye } from "lucide-react";
import type { DeliveryChallan, DeliveryChallanFormData } from "@/types/api";

export default function DeliveryChallans() {
  const [searchTerm, setSearchTerm] = useState("");
  const [vendorFilter, setVendorFilter] = useState("");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [viewingChallan, setViewingChallan] = useState<DeliveryChallan | null>(null);

  const { data, isLoading } = useDeliveryChallans();
  const { data: vendorsData } = useVendors();
  const createDeliveryChallan = useCreateDeliveryChallan();

  const deliveryChallans = data?.deliveryChallans || [];
  const vendors = vendorsData?.vendors || [];

  // Create vendor lookup map
  const vendorMap = vendors.reduce((acc, vendor) => {
    acc[vendor.id] = vendor.name;
    return acc;
  }, {} as Record<string, string>);

  // Filter challans
  const filteredChallans = deliveryChallans.filter(challan => {
    const vendorName = vendorMap[challan.vendorId] || "Unknown";
    const matchesSearch = challan.dcNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         vendorName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesVendor = !vendorFilter || vendorFilter === "all" || challan.vendorId === vendorFilter;
    return matchesSearch && matchesVendor;
  });

  const handleCreateChallan = async (data: DeliveryChallanFormData) => {
    await createDeliveryChallan.mutateAsync(data);
    setIsFormOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center">
            <FileText className="h-8 w-8 mr-3 text-primary" />
            Delivery Challans
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage delivery challans and purchase records
          </p>
        </div>
        <Button
          onClick={() => setIsFormOpen(true)}
          className="neuro-button"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Delivery Challan
        </Button>
      </div>

      {/* Search and Filters */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-2">
          <Card className="neuro-card">
            <CardContent className="p-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by DC number or vendor..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="neuro-input pl-10"
                />
              </div>
            </CardContent>
          </Card>
        </div>
        <Card className="neuro-card">
          <CardContent className="p-4">
            <Select value={vendorFilter} onValueChange={setVendorFilter}>
              <SelectTrigger className="neuro-input">
                <SelectValue placeholder="Filter by vendor" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Vendors</SelectItem>
                {vendors.map((vendor) => (
                  <SelectItem key={vendor.id} value={vendor.id}>
                    {vendor.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
        <Card className="neuro-card">
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-primary">{deliveryChallans.length}</p>
              <p className="text-sm text-muted-foreground">Total DCs</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Delivery Challans Table */}
      <Card className="neuro-card">
        <CardHeader>
          <CardTitle>All Delivery Challans</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <LoadingTable rows={5} />
          ) : filteredChallans.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-lg font-medium text-foreground mb-2">
                {searchTerm || vendorFilter ? "No delivery challans found" : "No delivery challans yet"}
              </p>
              <p className="text-muted-foreground mb-4">
                {searchTerm || vendorFilter
                  ? "Try adjusting your search or filters" 
                  : "Get started by creating your first delivery challan"
                }
              </p>
              {!searchTerm && !vendorFilter && (
                <Button
                  onClick={() => setIsFormOpen(true)}
                  className="neuro-button"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Delivery Challan
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left p-4 font-medium text-muted-foreground">DC Number</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Vendor</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Birds/Weight</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Rate</th>
                    <th className="text-left p-4 font-medium text-muted-foreground">Date</th>
                    <th className="text-right p-4 font-medium text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredChallans.map((challan) => (
                    <tr key={challan.id} className="border-b border-border last:border-b-0 hover:bg-muted/50">
                      <td className="p-4">
                        <p className="font-medium text-foreground">{challan.dcNumber}</p>
                      </td>
                      <td className="p-4">
                        <p className="text-foreground">{vendorMap[challan.vendorId] || "Unknown"}</p>
                      </td>
                      <td className="p-4">
                        <div className="space-y-1">
                          <p className="text-sm text-foreground">{challan.totalBirds} birds</p>
                          <p className="text-sm text-muted-foreground">{challan.totalWeight} kg</p>
                        </div>
                      </td>
                      <td className="p-4">
                        <Badge variant="outline" className="font-mono">
                          ₹{challan.purchaseRate.toFixed(2)}/kg
                        </Badge>
                      </td>
                      <td className="p-4">
                        <p className="text-sm text-muted-foreground">
                          {new Date(challan.date).toLocaleDateString()}
                        </p>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-end space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setViewingChallan(challan)}
                            className="neuro-button"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Delivery Challan Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="neuro-card border-0 max-w-4xl" aria-describedby="dc-dialog-description">
          <DialogHeader>
            <DialogTitle>Add New Delivery Challan</DialogTitle>
          </DialogHeader>
          <div id="dc-dialog-description" className="sr-only">
            Create a new delivery challan for tracking purchased goods
          </div>
          <DeliveryChallanForm
            onSubmit={handleCreateChallan}
            onCancel={() => setIsFormOpen(false)}
            isLoading={createDeliveryChallan.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* View Delivery Challan Dialog */}
      <Dialog open={!!viewingChallan} onOpenChange={() => setViewingChallan(null)}>
        <DialogContent className="neuro-card border-0 max-w-4xl" aria-describedby="dc-view-description">
          <DialogHeader>
            <DialogTitle>Delivery Challan Details</DialogTitle>
          </DialogHeader>
          <div id="dc-view-description" className="sr-only">
            View detailed information about the selected delivery challan
          </div>
          {viewingChallan && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">DC Number</Label>
                  <p className="text-lg font-semibold">{viewingChallan.dcNumber}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Vendor</Label>
                  <p className="text-lg">{vendorMap[viewingChallan.vendorId] || "Unknown"}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Date</Label>
                  <p className="text-lg">{new Date(viewingChallan.date).toLocaleDateString()}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Purchase Rate</Label>
                  <p className="text-lg">₹{viewingChallan.purchaseRate.toFixed(2)}/kg</p>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">Cages</h3>
                <div className="space-y-3">
                  {viewingChallan.cages.map((cage, index) => (
                    <div key={index} className="neuro-inset p-4">
                      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">Cage</Label>
                          <p className="font-medium">{cage.cageNumber}</p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">Birds</Label>
                          <p>{cage.birds}</p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">Weight</Label>
                          <p>{cage.weight} kg</p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">Rate</Label>
                          <p>₹{cage.rate.toFixed(2)}/kg</p>
                        </div>
                        <div>
                          <Label className="text-sm font-medium text-muted-foreground">Amount</Label>
                          <p className="font-semibold">₹{cage.amount.toFixed(2)}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="neuro-card p-4">
                <h4 className="font-semibold mb-3">Summary</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Total Birds</Label>
                    <p className="text-xl font-bold text-primary">{viewingChallan.totalBirds}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Total Weight</Label>
                    <p className="text-xl font-bold text-primary">{viewingChallan.totalWeight} kg</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground">Total Amount</Label>
                    <p className="text-xl font-bold text-primary">
                      ₹{viewingChallan.cages.reduce((sum, cage) => sum + cage.amount, 0).toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}