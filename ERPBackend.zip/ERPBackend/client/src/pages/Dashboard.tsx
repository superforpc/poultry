import { useDashboard, useInvoices, useLedger } from "@/hooks/useApi";
import { LoadingCard, LoadingSpinner } from "@/components/ui/loading";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  Truck, 
  FileText, 
  Receipt, 
  BookOpen, 
  TrendingUp,
  AlertCircle,
  CheckCircle
} from "lucide-react";

export default function Dashboard() {
  const { data: metrics, isLoading: metricsLoading } = useDashboard();
  const { data: invoicesData, isLoading: invoicesLoading } = useInvoices();
  const { data: ledgerData, isLoading: ledgerLoading } = useLedger();

  const invoices = invoicesData?.invoices || [];
  const ledgerEntries = ledgerData?.ledgerEntries || [];

  // Calculate some dashboard stats
  const recentInvoices = invoices
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const totalRevenue = invoices
    .filter(inv => inv.status === 'paid')
    .reduce((sum, inv) => sum + inv.total, 0);

  const pendingAmount = invoices
    .filter(inv => inv.status !== 'paid')
    .reduce((sum, inv) => sum + inv.dueAmount, 0);

  const totalOutstanding = ledgerEntries
    .filter(entry => entry.balance > 0)
    .reduce((sum, entry) => sum + entry.balance, 0);

  const statsCards = [
    {
      title: "Total Customers",
      value: metrics?.totalCustomers || 0,
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-50 dark:bg-blue-900/20"
    },
    {
      title: "Total Vendors", 
      value: metrics?.totalVendors || 0,
      icon: Truck,
      color: "text-green-600",
      bgColor: "bg-green-50 dark:bg-green-900/20"
    },
    {
      title: "Delivery Challans",
      value: metrics?.totalDeliveryChallans || 0,
      icon: FileText,
      color: "text-purple-600",
      bgColor: "bg-purple-50 dark:bg-purple-900/20"
    },
    {
      title: "Total Invoices",
      value: metrics?.totalInvoices || 0,
      icon: Receipt,
      color: "text-orange-600",
      bgColor: "bg-orange-50 dark:bg-orange-900/20"
    },
    {
      title: "Total Revenue",
      value: `₹${totalRevenue.toLocaleString()}`,
      icon: TrendingUp,
      color: "text-emerald-600",
      bgColor: "bg-emerald-50 dark:bg-emerald-900/20"
    },
    {
      title: "Pending Payments",
      value: `₹${pendingAmount.toLocaleString()}`,
      icon: AlertCircle,
      color: "text-red-600",
      bgColor: "bg-red-50 dark:bg-red-900/20"
    }
  ];

  if (metricsLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
          <p className="text-muted-foreground">Welcome to your ERP management system</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <LoadingCard key={i} />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Welcome to your ERP management system</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {statsCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="neuro-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">
                      {stat.title}
                    </p>
                    <p className="text-2xl font-bold text-foreground">
                      {stat.value}
                    </p>
                  </div>
                  <div className={`p-3 rounded-xl ${stat.bgColor}`}>
                    <Icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Invoices */}
        <Card className="neuro-card">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center">
              <Receipt className="h-5 w-5 mr-2 text-primary" />
              Recent Invoices
            </CardTitle>
          </CardHeader>
          <CardContent>
            {invoicesLoading ? (
              <LoadingSpinner text="Loading invoices..." />
            ) : recentInvoices.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                No invoices found
              </p>
            ) : (
              <div className="space-y-3">
                {recentInvoices.map((invoice) => (
                  <div key={invoice.id} className="flex items-center justify-between p-3 neuro-inset rounded-lg">
                    <div>
                      <p className="font-medium text-sm text-foreground">
                        {invoice.invoiceNumber}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(invoice.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-sm text-foreground">
                        ₹{invoice.total.toLocaleString()}
                      </p>
                      <Badge 
                        variant={invoice.status === 'paid' ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {invoice.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Outstanding Balances */}
        <Card className="neuro-card">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center">
              <BookOpen className="h-5 w-5 mr-2 text-primary" />
              Outstanding Balances
            </CardTitle>
          </CardHeader>
          <CardContent>
            {ledgerLoading ? (
              <LoadingSpinner text="Loading ledger..." />
            ) : (
              <div className="space-y-4">
                <div className="p-4 neuro-inset rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                      <span className="text-sm font-medium">Total Outstanding</span>
                    </div>
                    <span className="text-lg font-bold text-red-600">
                      ₹{totalOutstanding.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="p-4 neuro-inset rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                      <span className="text-sm font-medium">Total Paid</span>
                    </div>
                    <span className="text-lg font-bold text-green-600">
                      ₹{totalRevenue.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="p-4 neuro-inset rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <BookOpen className="h-5 w-5 text-blue-500 mr-2" />
                      <span className="text-sm font-medium">Total Ledger Entries</span>
                    </div>
                    <span className="text-lg font-bold text-blue-600">
                      {metrics?.totalLedgerEntries || 0}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}