import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type {
  Customer,
  Vendor,
  DeliveryChallan,
  Invoice,
  LedgerEntry,
  CustomerFormData,
  VendorFormData,
  DeliveryChallanFormData,
  InvoiceFormData,
  DashboardMetrics,
  ApiResponse
} from "@/types/api";

// Dashboard hook
export function useDashboard() {
  return useQuery({
    queryKey: ['/api/test'],
    select: (data: any): DashboardMetrics => ({
      totalCustomers: data.database?.tables?.customers || 0,
      totalVendors: data.database?.tables?.vendors || 0,
      totalDeliveryChallans: data.database?.tables?.deliveryChallans || 0,
      totalInvoices: data.database?.tables?.invoices || 0,
      totalLedgerEntries: data.database?.tables?.ledgerEntries || 0,
      recentInvoices: [],
      pendingPayments: 0,
      totalRevenue: 0
    })
  });
}

// Customer hooks
export function useCustomers() {
  return useQuery<ApiResponse<Customer>>({
    queryKey: ['/api/customers']
  });
}

export function useCustomer(id: string) {
  return useQuery<Customer>({
    queryKey: ['/api/customers', id],
    enabled: !!id
  });
}

export function useCreateCustomer() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (data: CustomerFormData) => 
      apiRequest('POST', '/api/customers', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/test'] });
      toast({
        title: "Success",
        description: "Customer created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create customer",
        variant: "destructive",
      });
    }
  });
}

export function useUpdateCustomer() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<CustomerFormData> }) =>
      apiRequest('PUT', `/api/customers/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
      toast({
        title: "Success",
        description: "Customer updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update customer",
        variant: "destructive",
      });
    }
  });
}

export function useDeleteCustomer() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (id: string) =>
      apiRequest('DELETE', `/api/customers/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/test'] });
      toast({
        title: "Success",
        description: "Customer deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete customer",
        variant: "destructive",
      });
    }
  });
}

// Vendor hooks
export function useVendors() {
  return useQuery<ApiResponse<Vendor>>({
    queryKey: ['/api/vendors']
  });
}

export function useVendor(id: string) {
  return useQuery<Vendor>({
    queryKey: ['/api/vendors', id],
    enabled: !!id
  });
}

export function useCreateVendor() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (data: VendorFormData) =>
      apiRequest('POST', '/api/vendors', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vendors'] });
      queryClient.invalidateQueries({ queryKey: ['/api/test'] });
      toast({
        title: "Success",
        description: "Vendor created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create vendor",
        variant: "destructive",
      });
    }
  });
}

export function useUpdateVendor() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<VendorFormData> }) =>
      apiRequest('PUT', `/api/vendors/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vendors'] });
      toast({
        title: "Success",
        description: "Vendor updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update vendor",
        variant: "destructive",
      });
    }
  });
}

export function useDeleteVendor() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (id: string) =>
      apiRequest('DELETE', `/api/vendors/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vendors'] });
      queryClient.invalidateQueries({ queryKey: ['/api/test'] });
      toast({
        title: "Success",
        description: "Vendor deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete vendor",
        variant: "destructive",
      });
    }
  });
}

// Delivery Challan hooks
export function useDeliveryChallans(vendorId?: string) {
  return useQuery<ApiResponse<DeliveryChallan>>({
    queryKey: vendorId ? ['/api/delivery-challans', { vendorId }] : ['/api/delivery-challans']
  });
}

export function useDeliveryChallan(id: string) {
  return useQuery<DeliveryChallan>({
    queryKey: ['/api/delivery-challans', id],
    enabled: !!id
  });
}

export function useCreateDeliveryChallan() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (data: DeliveryChallanFormData) =>
      apiRequest('POST', '/api/delivery-challans', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/delivery-challans'] });
      queryClient.invalidateQueries({ queryKey: ['/api/vendors'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ledger'] });
      queryClient.invalidateQueries({ queryKey: ['/api/test'] });
      toast({
        title: "Success",
        description: "Delivery challan created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create delivery challan",
        variant: "destructive",
      });
    }
  });
}

// Invoice hooks
export function useInvoices(filters?: { customerId?: string; status?: string }) {
  return useQuery<ApiResponse<Invoice>>({
    queryKey: filters ? ['/api/invoices', filters] : ['/api/invoices']
  });
}

export function useInvoice(id: string) {
  return useQuery<Invoice>({
    queryKey: ['/api/invoices', id],
    enabled: !!id
  });
}

export function useCreateInvoice() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (data: InvoiceFormData) =>
      apiRequest('POST', '/api/invoices', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/invoices'] });
      queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ledger'] });
      queryClient.invalidateQueries({ queryKey: ['/api/test'] });
      toast({
        title: "Success",
        description: "Invoice created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create invoice",
        variant: "destructive",
      });
    }
  });
}

// Ledger hooks
export function useLedger(filters?: { customerId?: string; vendorId?: string }) {
  return useQuery<ApiResponse<LedgerEntry>>({
    queryKey: filters ? ['/api/ledger', filters] : ['/api/ledger']
  });
}

export function useLedgerEntry(id: string) {
  return useQuery<LedgerEntry>({
    queryKey: ['/api/ledger', id],
    enabled: !!id
  });
}