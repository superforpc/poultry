import { useEffect, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";

// Real-time data synchronization using polling
// This ensures all data updates immediately across all components
export function useRealTimeSync() {
  const queryClient = useQueryClient();

  const syncData = useCallback(async () => {
    // Invalidate all queries to refetch latest data
    await queryClient.invalidateQueries({ queryKey: ['/api/customers'] });
    await queryClient.invalidateQueries({ queryKey: ['/api/vendors'] });
    await queryClient.invalidateQueries({ queryKey: ['/api/delivery-challans'] });
    await queryClient.invalidateQueries({ queryKey: ['/api/invoices'] });
    await queryClient.invalidateQueries({ queryKey: ['/api/ledger'] });
    await queryClient.invalidateQueries({ queryKey: ['/api/test'] });
  }, [queryClient]);

  useEffect(() => {
    // Set up polling for real-time updates every 30 seconds
    const interval = setInterval(syncData, 30000);

    // Also sync when the page becomes visible again
    const handleVisibilityChange = () => {
      if (!document.hidden) {
        syncData();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [syncData]);

  // Manual sync function for after mutations
  const triggerSync = useCallback(() => {
    syncData();
  }, [syncData]);

  return { triggerSync };
}