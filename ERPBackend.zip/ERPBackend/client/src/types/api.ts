// API Types based on the backend schema
export interface Customer {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  balance: number;
  createdAt: string;
}

export interface Vendor {
  id: string;
  name: string;
  balance: number;
  createdAt: string;
}

export interface CageData {
  cageNumber: string;
  birds: number;
  weight: number;
  rate: number;
  amount: number;
}

export interface DeliveryChallan {
  id: string;
  dcNumber: string;
  vendorId: string;
  date: string;
  totalBirds: number;
  totalWeight: number;
  purchaseRate: number;
  cages: CageData[];
  createdAt: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  customerId: string;
  cages: CageData[];
  subtotal: number;
  tax: number;
  total: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod: "cash" | "bank_transfer" | "cheque" | "online";
  status: "pending" | "partial" | "paid" | "overdue";
  createdAt: string;
}

export interface LedgerEntry {
  id: string;
  relatedId: string;
  type: "purchase" | "invoice" | "payment";
  customerOrVendorName: string;
  description: string;
  amount: number;
  paid: number;
  balance: number;
  date: string;
  createdAt: string;
}

// API Response types
export interface ApiResponse<T> {
  [key: string]: T[];
}

export interface ApiError {
  error: string;
  message?: string;
  details?: string;
}

// Form data types
export interface CustomerFormData {
  name: string;
  phone?: string;
  email?: string;
  balance: number;
}

export interface VendorFormData {
  name: string;
  balance: number;
}

export interface DeliveryChallanFormData {
  dcNumber: string;
  vendorName?: string;
  vendorId?: string;
  date: string;
  totalBirds: number;
  totalWeight: number;
  purchaseRate: number;
  cages: CageData[];
}

export interface InvoiceFormData {
  invoiceNumber: string;
  customerId: string;
  cages: CageData[];
  subtotal: number;
  tax: number;
  total: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod: "cash" | "bank_transfer" | "cheque" | "online";
  status: "pending" | "partial" | "paid" | "overdue";
}

// Dashboard metrics
export interface DashboardMetrics {
  totalCustomers: number;
  totalVendors: number;
  totalDeliveryChallans: number;
  totalInvoices: number;
  totalLedgerEntries: number;
  recentInvoices: Invoice[];
  pendingPayments: number;
  totalRevenue: number;
}