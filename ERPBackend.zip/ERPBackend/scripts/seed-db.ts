import { storage } from "../server/storage";
import { initializeDatabase, closeDatabase } from "../server/database";

async function seedDatabase() {
  console.log("🌱 Seeding database with test data...");
  
  try {
    // Initialize database first
    initializeDatabase();
    
    // Create test customers
    console.log("Creating test customers...");
    const customer1 = await storage.createCustomer({
      name: "ABC Poultry Farm",
      phone: "+91-9876543210",
      email: "contact@abcpoultry.com",
      balance: 0
    });
    
    const customer2 = await storage.createCustomer({
      name: "XYZ Chicken Center",
      phone: "+91-8765432109",
      email: "info@xyzmeat.com",
      balance: 0
    });
    
    console.log(`✅ Created customers: ${customer1.name}, ${customer2.name}`);
    
    // Create test vendors
    console.log("Creating test vendors...");
    const vendor1 = await storage.createVendor({
      name: "Village Farm Supplier",
      balance: 0
    });
    
    const vendor2 = await storage.createVendor({
      name: "Rural Poultry Co.",
      balance: 0
    });
    
    console.log(`✅ Created vendors: ${vendor1.name}, ${vendor2.name}`);
    
    // Create test delivery challans
    console.log("Creating test delivery challans...");
    const currentDate = new Date().toISOString();
    
    const challan1 = await storage.createDeliveryChallan({
      dcNumber: "19-7-25sgn-001",
      vendorId: vendor1.id,
      date: currentDate,
      totalBirds: 100,
      totalWeight: 150.5,
      purchaseRate: 85.50,
      cages: [
        { cageNumber: "CAGE-001", birds: 50, weight: 75.2, rate: 85.50, amount: 6433.26 },
        { cageNumber: "CAGE-002", birds: 50, weight: 75.3, rate: 85.50, amount: 6438.15 }
      ]
    });
    
    const challan2 = await storage.createDeliveryChallan({
      dcNumber: "19-7-25sgn-002",
      vendorId: vendor2.id,
      date: currentDate,
      totalBirds: 80,
      totalWeight: 120.0,
      purchaseRate: 82.00,
      cages: [
        { cageNumber: "CAGE-003", birds: 80, weight: 120.0, rate: 82.00, amount: 9840.00 }
      ]
    });
    
    console.log(`✅ Created delivery challans: ${challan1.dcNumber}, ${challan2.dcNumber}`);
    
    // Create test invoices
    console.log("Creating test invoices...");
    const invoice1 = await storage.createInvoice({
      invoiceNumber: "INV-2025-001",
      customerId: customer1.id,
      cages: [
        { cageNumber: "CAGE-001", birds: 50, weight: 75.2, rate: 120.00, amount: 9024.00 },
        { cageNumber: "CAGE-002", birds: 50, weight: 75.3, rate: 120.00, amount: 9036.00 }
      ],
      subtotal: 18060.00,
      tax: 3250.80, // 18% GST
      total: 21310.80,
      paidAmount: 15000.00,
      dueAmount: 6310.80,
      paymentMethod: "bank_transfer",
      status: "partial"
    });
    
    const invoice2 = await storage.createInvoice({
      invoiceNumber: "INV-2025-002",
      customerId: customer2.id,
      cages: [
        { cageNumber: "CAGE-003", birds: 80, weight: 120.0, rate: 125.00, amount: 15000.00 }
      ],
      subtotal: 15000.00,
      tax: 2700.00, // 18% GST
      total: 17700.00,
      paidAmount: 17700.00,
      dueAmount: 0,
      paymentMethod: "cash",
      status: "paid"
    });
    
    console.log(`✅ Created invoices: ${invoice1.invoiceNumber}, ${invoice2.invoiceNumber}`);
    
    // The ledger entries are automatically created by the createDeliveryChallan and createInvoice methods
    
    // Display summary
    console.log("\n📊 Database seeding completed successfully!");
    console.log("📈 Summary:");
    console.log(`   - Customers: ${(await storage.getAllCustomers()).length}`);
    console.log(`   - Vendors: ${(await storage.getAllVendors()).length}`);
    console.log(`   - Delivery Challans: ${(await storage.getAllDeliveryChallans()).length}`);
    console.log(`   - Invoices: ${(await storage.getAllInvoices()).length}`);
    console.log(`   - Ledger Entries: ${(await storage.getAllLedgerEntries()).length}`);
    
  } catch (error) {
    console.error("❌ Failed to seed database:", error);
    process.exit(1);
  } finally {
    closeDatabase();
  }
}

seedDatabase();
