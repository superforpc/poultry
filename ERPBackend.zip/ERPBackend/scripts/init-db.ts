import { initializeDatabase, testDatabaseConnection, closeDatabase } from "../server/database";

async function main() {
  console.log("🚀 Initializing ERP Database...");
  
  try {
    // Initialize database and create tables
    initializeDatabase();
    
    // Test the connection
    const isConnected = testDatabaseConnection();
    
    if (isConnected) {
      console.log("✅ Database initialized successfully!");
      console.log("📋 Tables created:");
      console.log("   - users");
      console.log("   - customers");
      console.log("   - cages");
      console.log("   - delivery_challans");
      console.log("   - invoices");
      console.log("   - ledger_entries");
      console.log("");
      console.log("🎯 Database is ready for use!");
    } else {
      console.error("❌ Database connection test failed");
      process.exit(1);
    }
    
  } catch (error) {
    console.error("❌ Failed to initialize database:", error);
    process.exit(1);
  } finally {
    closeDatabase();
  }
}

main();
