import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import { migrate } from "drizzle-orm/better-sqlite3/migrator";
import path from "path";
import fs from "fs";
import * as schema from "@shared/schema";

const dbPath = process.env.DATABASE_PATH || "erp.db";
const migrationsPath = path.join(process.cwd(), "drizzle");

// Ensure the database directory exists
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

// Create SQLite database connection
const sqlite = new Database(dbPath);
sqlite.pragma("journal_mode = WAL");
sqlite.pragma("foreign_keys = ON");

// Create Drizzle database instance
export const db = drizzle(sqlite, { schema });

// Initialize database with tables
export function initializeDatabase() {
  try {
    console.log("Initializing database...");
    
    // Enable foreign keys
    sqlite.pragma("foreign_keys = ON");
    
    // Create tables manually since we're not using migrations for this setup
    const createTables = `
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS customers (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        balance REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS vendors (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        name TEXT NOT NULL,
        balance REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS delivery_challans (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        dc_number TEXT NOT NULL UNIQUE,
        vendor_id TEXT NOT NULL REFERENCES vendors(id),
        date TEXT NOT NULL,
        total_birds INTEGER NOT NULL DEFAULT 0,
        total_weight REAL NOT NULL DEFAULT 0,
        purchase_rate REAL NOT NULL DEFAULT 0,
        cages TEXT NOT NULL DEFAULT '[]',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS invoices (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        invoice_number TEXT NOT NULL UNIQUE,
        customer_id TEXT NOT NULL REFERENCES customers(id),
        cages TEXT NOT NULL DEFAULT '[]',
        subtotal REAL NOT NULL DEFAULT 0,
        tax REAL NOT NULL DEFAULT 0,
        total REAL NOT NULL DEFAULT 0,
        paid_amount REAL NOT NULL DEFAULT 0,
        due_amount REAL NOT NULL DEFAULT 0,
        payment_method TEXT,
        status TEXT NOT NULL DEFAULT 'draft',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS ledger_entries (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        related_id TEXT,
        type TEXT NOT NULL,
        customer_or_vendor_name TEXT NOT NULL,
        description TEXT NOT NULL,
        amount REAL NOT NULL,
        paid REAL NOT NULL DEFAULT 0,
        balance REAL NOT NULL DEFAULT 0,
        date TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE INDEX IF NOT EXISTS idx_customers_name ON customers(name);
      CREATE INDEX IF NOT EXISTS idx_vendors_name ON vendors(name);
      CREATE INDEX IF NOT EXISTS idx_challans_vendor ON delivery_challans(vendor_id);
      CREATE INDEX IF NOT EXISTS idx_challans_date ON delivery_challans(date);
      CREATE INDEX IF NOT EXISTS idx_invoices_customer ON invoices(customer_id);
      CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
      CREATE INDEX IF NOT EXISTS idx_ledger_type ON ledger_entries(type);
      CREATE INDEX IF NOT EXISTS idx_ledger_date ON ledger_entries(date);
    `;

    sqlite.exec(createTables);
    console.log("Database tables created successfully");
    
  } catch (error) {
    console.error("Failed to initialize database:", error);
    throw error;
  }
}

// Test database connection
export function testDatabaseConnection() {
  try {
    const result = sqlite.prepare("SELECT 1 as test").get();
    console.log("Database connection test successful:", result);
    return true;
  } catch (error) {
    console.error("Database connection test failed:", error);
    return false;
  }
}

// Close database connection
export function closeDatabase() {
  sqlite.close();
}

// Export sqlite instance for direct queries if needed
export { sqlite };
