import { eq, desc, and, like, sql } from "drizzle-orm";
import { db } from "./database";
import * as schema from "@shared/schema";
import type {
  User, InsertUser,
  Customer, InsertCustomer,
  Vendor, InsertVendor,
  DeliveryChallan, InsertDeliveryChallan,
  Invoice, InsertInvoice,
  LedgerEntry, InsertLedgerEntry
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Customers
  getCustomer(id: string): Promise<Customer | undefined>;
  getAllCustomers(): Promise<Customer[]>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: string, updates: Partial<InsertCustomer>): Promise<Customer | undefined>;
  deleteCustomer(id: string): Promise<boolean>;

  // Vendors
  getVendor(id: string): Promise<Vendor | undefined>;
  getAllVendors(): Promise<Vendor[]>;
  getVendorByName(name: string): Promise<Vendor | undefined>;
  createVendor(vendor: InsertVendor): Promise<Vendor>;
  updateVendor(id: string, updates: Partial<InsertVendor>): Promise<Vendor | undefined>;
  deleteVendor(id: string): Promise<boolean>;

  // Delivery Challans
  getDeliveryChallan(id: string): Promise<DeliveryChallan | undefined>;
  getAllDeliveryChallans(): Promise<DeliveryChallan[]>;
  getDeliveryChallansByVendor(vendorId: string): Promise<DeliveryChallan[]>;
  createDeliveryChallan(challan: InsertDeliveryChallan): Promise<DeliveryChallan>;
  updateDeliveryChallan(id: string, updates: Partial<InsertDeliveryChallan>): Promise<DeliveryChallan | undefined>;
  deleteDeliveryChallan(id: string): Promise<boolean>;

  // Invoices
  getInvoice(id: string): Promise<Invoice | undefined>;
  getAllInvoices(): Promise<Invoice[]>;
  getInvoicesByCustomer(customerId: string): Promise<Invoice[]>;
  getInvoicesByStatus(status: string): Promise<Invoice[]>;
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: string, updates: Partial<InsertInvoice>): Promise<Invoice | undefined>;
  deleteInvoice(id: string): Promise<boolean>;

  // Ledger Entries
  getLedgerEntry(id: string): Promise<LedgerEntry | undefined>;
  getAllLedgerEntries(): Promise<LedgerEntry[]>;
  getLedgerEntriesByCustomerId(customerId: string): Promise<LedgerEntry[]>;
  getLedgerEntriesByVendorId(vendorId: string): Promise<LedgerEntry[]>;
  createLedgerEntry(entry: InsertLedgerEntry): Promise<LedgerEntry>;
  updateLedgerEntry(id: string, updates: Partial<InsertLedgerEntry>): Promise<LedgerEntry | undefined>;
  deleteLedgerEntry(id: string): Promise<boolean>;
}

export class SQLiteStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(schema.users).values(user).returning();
    return newUser;
  }

  // Customers
  async getCustomer(id: string): Promise<Customer | undefined> {
    const [customer] = await db.select().from(schema.customers).where(eq(schema.customers.id, id));
    return customer;
  }

  async getAllCustomers(): Promise<Customer[]> {
    return await db.select().from(schema.customers).orderBy(desc(schema.customers.name));
  }

  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const [newCustomer] = await db.insert(schema.customers).values(customer).returning();
    return newCustomer;
  }

  async updateCustomer(id: string, updates: Partial<InsertCustomer>): Promise<Customer | undefined> {
    const [updatedCustomer] = await db.update(schema.customers)
      .set(updates)
      .where(eq(schema.customers.id, id))
      .returning();
    return updatedCustomer;
  }

  async deleteCustomer(id: string): Promise<boolean> {
    const result = await db.delete(schema.customers).where(eq(schema.customers.id, id));
    return result.changes > 0;
  }

  // Vendors
  async getVendor(id: string): Promise<Vendor | undefined> {
    const [vendor] = await db.select().from(schema.vendors).where(eq(schema.vendors.id, id));
    return vendor;
  }

  async getAllVendors(): Promise<Vendor[]> {
    return await db.select().from(schema.vendors).orderBy(desc(schema.vendors.name));
  }

  async getVendorByName(name: string): Promise<Vendor | undefined> {
    const [vendor] = await db.select().from(schema.vendors).where(eq(schema.vendors.name, name));
    return vendor;
  }

  async createVendor(vendor: InsertVendor): Promise<Vendor> {
    const [newVendor] = await db.insert(schema.vendors).values(vendor).returning();
    return newVendor;
  }

  async updateVendor(id: string, updates: Partial<InsertVendor>): Promise<Vendor | undefined> {
    const [updatedVendor] = await db.update(schema.vendors)
      .set(updates)
      .where(eq(schema.vendors.id, id))
      .returning();
    return updatedVendor;
  }

  async deleteVendor(id: string): Promise<boolean> {
    const result = await db.delete(schema.vendors).where(eq(schema.vendors.id, id));
    return result.changes > 0;
  }

  // Delivery Challans
  async getDeliveryChallan(id: string): Promise<DeliveryChallan | undefined> {
    const [challan] = await db.select().from(schema.deliveryChallans)
      .where(eq(schema.deliveryChallans.id, id));
    return challan;
  }

  async getAllDeliveryChallans(): Promise<DeliveryChallan[]> {
    return await db.select().from(schema.deliveryChallans)
      .orderBy(desc(schema.deliveryChallans.date));
  }

  async getDeliveryChallansByVendor(vendorId: string): Promise<DeliveryChallan[]> {
    return await db.select().from(schema.deliveryChallans)
      .where(eq(schema.deliveryChallans.vendorId, vendorId))
      .orderBy(desc(schema.deliveryChallans.date));
  }

  async createDeliveryChallan(challan: InsertDeliveryChallan): Promise<DeliveryChallan> {
    const [newChallan] = await db.insert(schema.deliveryChallans).values(challan).returning();
    
    // Auto-create ledger entry for vendor
    const vendor = await this.getVendor(challan.vendorId);
    if (vendor) {
      const totalAmount = challan.totalBirds * challan.purchaseRate;
      await this.createLedgerEntry({
        relatedId: newChallan.id,
        type: "purchase",
        customerOrVendorName: vendor.name,
        description: `Purchase DC: ${newChallan.dcNumber}`,
        amount: totalAmount,
        paid: 0,
        balance: totalAmount,
        date: challan.date
      });
    }
    
    return newChallan;
  }

  async updateDeliveryChallan(id: string, updates: Partial<InsertDeliveryChallan>): Promise<DeliveryChallan | undefined> {
    const [updatedChallan] = await db.update(schema.deliveryChallans)
      .set(updates)
      .where(eq(schema.deliveryChallans.id, id))
      .returning();
    return updatedChallan;
  }

  async deleteDeliveryChallan(id: string): Promise<boolean> {
    const result = await db.delete(schema.deliveryChallans)
      .where(eq(schema.deliveryChallans.id, id));
    return result.changes > 0;
  }

  // Invoices
  async getInvoice(id: string): Promise<Invoice | undefined> {
    const [invoice] = await db.select().from(schema.invoices)
      .where(eq(schema.invoices.id, id));
    return invoice;
  }

  async getAllInvoices(): Promise<Invoice[]> {
    return await db.select().from(schema.invoices)
      .orderBy(desc(schema.invoices.createdAt));
  }

  async getInvoicesByCustomer(customerId: string): Promise<Invoice[]> {
    return await db.select().from(schema.invoices)
      .where(eq(schema.invoices.customerId, customerId))
      .orderBy(desc(schema.invoices.createdAt));
  }

  async getInvoicesByStatus(status: string): Promise<Invoice[]> {
    return await db.select().from(schema.invoices)
      .where(eq(schema.invoices.status, status))
      .orderBy(desc(schema.invoices.createdAt));
  }

  async createInvoice(invoice: InsertInvoice): Promise<Invoice> {
    const [newInvoice] = await db.insert(schema.invoices).values(invoice).returning();
    
    // Auto-create ledger entry for customer
    const customer = await this.getCustomer(invoice.customerId);
    if (customer) {
      await this.createLedgerEntry({
        relatedId: newInvoice.id,
        type: "invoice",
        customerOrVendorName: customer.name,
        description: `Invoice: ${newInvoice.invoiceNumber}`,
        amount: invoice.total,
        paid: invoice.paidAmount,
        balance: invoice.dueAmount,
        date: new Date().toISOString()
      });
    }
    
    return newInvoice;
  }

  async updateInvoice(id: string, updates: Partial<InsertInvoice>): Promise<Invoice | undefined> {
    const [updatedInvoice] = await db.update(schema.invoices)
      .set(updates)
      .where(eq(schema.invoices.id, id))
      .returning();
    return updatedInvoice;
  }

  async deleteInvoice(id: string): Promise<boolean> {
    const result = await db.delete(schema.invoices).where(eq(schema.invoices.id, id));
    return result.changes > 0;
  }

  // Ledger Entries
  async getLedgerEntry(id: string): Promise<LedgerEntry | undefined> {
    const [entry] = await db.select().from(schema.ledgerEntries)
      .where(eq(schema.ledgerEntries.id, id));
    return entry;
  }

  async getAllLedgerEntries(): Promise<LedgerEntry[]> {
    return await db.select().from(schema.ledgerEntries)
      .orderBy(desc(schema.ledgerEntries.date));
  }

  async getLedgerEntriesByCustomerId(customerId: string): Promise<LedgerEntry[]> {
    const customer = await this.getCustomer(customerId);
    if (!customer) return [];
    
    return await db.select().from(schema.ledgerEntries)
      .where(eq(schema.ledgerEntries.customerOrVendorName, customer.name))
      .orderBy(desc(schema.ledgerEntries.date));
  }

  async getLedgerEntriesByVendorId(vendorId: string): Promise<LedgerEntry[]> {
    const vendor = await this.getVendor(vendorId);
    if (!vendor) return [];
    
    return await db.select().from(schema.ledgerEntries)
      .where(eq(schema.ledgerEntries.customerOrVendorName, vendor.name))
      .orderBy(desc(schema.ledgerEntries.date));
  }

  async createLedgerEntry(entry: InsertLedgerEntry): Promise<LedgerEntry> {
    const [newEntry] = await db.insert(schema.ledgerEntries).values(entry).returning();
    return newEntry;
  }

  async updateLedgerEntry(id: string, updates: Partial<InsertLedgerEntry>): Promise<LedgerEntry | undefined> {
    const [updatedEntry] = await db.update(schema.ledgerEntries)
      .set(updates)
      .where(eq(schema.ledgerEntries.id, id))
      .returning();
    return updatedEntry;
  }

  async deleteLedgerEntry(id: string): Promise<boolean> {
    const result = await db.delete(schema.ledgerEntries)
      .where(eq(schema.ledgerEntries.id, id));
    return result.changes > 0;
  }
}

export const storage = new SQLiteStorage();
