import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { initializeDatabase, testDatabaseConnection } from "./database";
import {
  insertCustomerSchema,
  insertVendorSchema,
  insertDeliveryChallanSchema,
  insertInvoiceSchema,
  insertLedgerEntrySchema
} from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize database on startup
  initializeDatabase();

  // Test endpoint
  app.get("/api/test", async (req, res) => {
    try {
      const dbConnected = testDatabaseConnection();
      const customerCount = (await storage.getAllCustomers()).length;
      const vendorCount = (await storage.getAllVendors()).length;
      const challanCount = (await storage.getAllDeliveryChallans()).length;
      const invoiceCount = (await storage.getAllInvoices()).length;
      const ledgerCount = (await storage.getAllLedgerEntries()).length;

      res.json({
        status: "success",
        message: "ERP Backend is running successfully",
        database: {
          connected: dbConnected,
          tables: {
            customers: customerCount,
            vendors: vendorCount,
            deliveryChallans: challanCount,
            invoices: invoiceCount,
            ledgerEntries: ledgerCount
          }
        },
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({
        status: "error",
        message: "Database connection failed",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Customer routes
  app.get("/api/customers", async (req, res) => {
    try {
      const customers = await storage.getAllCustomers();
      res.json({ customers });
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to fetch customers", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/customers/:id", async (req, res) => {
    try {
      const customer = await storage.getCustomer(req.params.id);
      if (!customer) {
        return res.status(404).json({ error: "Customer not found" });
      }
      res.json({ customer });
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to fetch customer", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.post("/api/customers", async (req, res) => {
    try {
      const validatedData = insertCustomerSchema.parse(req.body);
      const customer = await storage.createCustomer(validatedData);
      res.status(201).json({ customer, message: "Customer created successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: "Validation failed", details: validationError.message });
      }
      res.status(500).json({ 
        error: "Failed to create customer", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.put("/api/customers/:id", async (req, res) => {
    try {
      const validatedData = insertCustomerSchema.partial().parse(req.body);
      const customer = await storage.updateCustomer(req.params.id, validatedData);
      if (!customer) {
        return res.status(404).json({ error: "Customer not found" });
      }
      res.json({ customer, message: "Customer updated successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: "Validation failed", details: validationError.message });
      }
      res.status(500).json({ 
        error: "Failed to update customer", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.delete("/api/customers/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteCustomer(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Customer not found" });
      }
      res.json({ message: "Customer deleted successfully" });
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to delete customer", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Vendor routes
  app.get("/api/vendors", async (req, res) => {
    try {
      const vendors = await storage.getAllVendors();
      res.json({ vendors });
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to fetch vendors", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/vendors/:id", async (req, res) => {
    try {
      const vendor = await storage.getVendor(req.params.id);
      if (!vendor) {
        return res.status(404).json({ error: "Vendor not found" });
      }
      res.json({ vendor });
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to fetch vendor", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.post("/api/vendors", async (req, res) => {
    try {
      const validatedData = insertVendorSchema.parse(req.body);
      const vendor = await storage.createVendor(validatedData);
      res.status(201).json({ vendor, message: "Vendor created successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: "Validation failed", details: validationError.message });
      }
      res.status(500).json({ 
        error: "Failed to create vendor", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.put("/api/vendors/:id", async (req, res) => {
    try {
      const validatedData = insertVendorSchema.partial().parse(req.body);
      const vendor = await storage.updateVendor(req.params.id, validatedData);
      if (!vendor) {
        return res.status(404).json({ error: "Vendor not found" });
      }
      res.json({ vendor, message: "Vendor updated successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: "Validation failed", details: validationError.message });
      }
      res.status(500).json({ 
        error: "Failed to update vendor", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.delete("/api/vendors/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteVendor(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Vendor not found" });
      }
      res.json({ message: "Vendor deleted successfully" });
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to delete vendor", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Delivery Challan routes
  app.get("/api/delivery-challans", async (req, res) => {
    try {
      const { vendorId } = req.query;
      let challans;
      if (vendorId) {
        challans = await storage.getDeliveryChallansByVendor(vendorId as string);
      } else {
        challans = await storage.getAllDeliveryChallans();
      }
      res.json({ deliveryChallans: challans });
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to fetch delivery challans", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/delivery-challans/:id", async (req, res) => {
    try {
      const challan = await storage.getDeliveryChallan(req.params.id);
      if (!challan) {
        return res.status(404).json({ error: "Delivery challan not found" });
      }
      res.json({ deliveryChallan: challan });
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to fetch delivery challan", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.post("/api/delivery-challans", async (req, res) => {
    try {
      // Extract vendorName from request body for processing
      const { vendorName, ...challanData } = req.body;
      
      // Check if vendor exists, create if not
      let vendor;
      if (vendorName) {
        vendor = await storage.getVendorByName(vendorName);
        if (!vendor) {
          vendor = await storage.createVendor({ 
            name: vendorName, 
            balance: 0 
          });
        }
      } else if (challanData.vendorId) {
        vendor = await storage.getVendor(challanData.vendorId);
        if (!vendor) {
          return res.status(400).json({ error: "Vendor not found" });
        }
      } else {
        return res.status(400).json({ error: "Either vendorName or vendorId is required" });
      }
      
      // Create the delivery challan data with the vendor ID
      const finalChallanData = {
        ...challanData,
        vendorId: vendor.id
      };
      
      // Validate the final data
      const validatedData = insertDeliveryChallanSchema.parse(finalChallanData);
      
      const challan = await storage.createDeliveryChallan(validatedData);
      res.status(201).json({ deliveryChallan: challan, message: "Delivery challan created successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: "Validation failed", details: validationError.message });
      }
      res.status(500).json({ 
        error: "Failed to create delivery challan", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.patch("/api/delivery-challans/:id", async (req, res) => {
    try {
      const validatedData = insertDeliveryChallanSchema.partial().parse(req.body);
      const challan = await storage.updateDeliveryChallan(req.params.id, validatedData);
      if (!challan) {
        return res.status(404).json({ error: "Delivery challan not found" });
      }
      res.json({ deliveryChallan: challan, message: "Delivery challan updated successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: "Validation failed", details: validationError.message });
      }
      res.status(500).json({ 
        error: "Failed to update delivery challan", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Invoice routes
  app.get("/api/invoices", async (req, res) => {
    try {
      const { status, customerId } = req.query;
      let invoices;
      if (customerId) {
        invoices = await storage.getInvoicesByCustomer(customerId as string);
      } else if (status) {
        invoices = await storage.getInvoicesByStatus(status as string);
      } else {
        invoices = await storage.getAllInvoices();
      }
      res.json({ invoices });
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to fetch invoices", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/invoices/:id", async (req, res) => {
    try {
      const invoice = await storage.getInvoice(req.params.id);
      if (!invoice) {
        return res.status(404).json({ error: "Invoice not found" });
      }
      res.json({ invoice });
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to fetch invoice", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.post("/api/invoices", async (req, res) => {
    try {
      const validatedData = insertInvoiceSchema.parse(req.body);
      const invoice = await storage.createInvoice(validatedData);
      res.status(201).json({ invoice, message: "Invoice created successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: "Validation failed", details: validationError.message });
      }
      res.status(500).json({ 
        error: "Failed to create invoice", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.patch("/api/invoices/:id", async (req, res) => {
    try {
      const validatedData = insertInvoiceSchema.partial().parse(req.body);
      const invoice = await storage.updateInvoice(req.params.id, validatedData);
      if (!invoice) {
        return res.status(404).json({ error: "Invoice not found" });
      }
      res.json({ invoice, message: "Invoice updated successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: "Validation failed", details: validationError.message });
      }
      res.status(500).json({ 
        error: "Failed to update invoice", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Ledger Entry routes
  app.get("/api/ledger", async (req, res) => {
    try {
      const { customerId, vendorId } = req.query;
      let entries;
      if (customerId) {
        entries = await storage.getLedgerEntriesByCustomerId(customerId as string);
      } else if (vendorId) {
        entries = await storage.getLedgerEntriesByVendorId(vendorId as string);
      } else {
        entries = await storage.getAllLedgerEntries();
      }
      res.json({ ledgerEntries: entries });
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to fetch ledger entries", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.get("/api/ledger/:id", async (req, res) => {
    try {
      const entry = await storage.getLedgerEntry(req.params.id);
      if (!entry) {
        return res.status(404).json({ error: "Ledger entry not found" });
      }
      res.json({ ledgerEntry: entry });
    } catch (error) {
      res.status(500).json({ 
        error: "Failed to fetch ledger entry", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  app.patch("/api/ledger/:id", async (req, res) => {
    try {
      const validatedData = insertLedgerEntrySchema.partial().parse(req.body);
      const entry = await storage.updateLedgerEntry(req.params.id, validatedData);
      if (!entry) {
        return res.status(404).json({ error: "Ledger entry not found" });
      }
      res.json({ ledgerEntry: entry, message: "Ledger entry updated successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: "Validation failed", details: validationError.message });
      }
      res.status(500).json({ 
        error: "Failed to update ledger entry", 
        message: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
